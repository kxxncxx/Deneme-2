package com.example.hesap

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

class SecretActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var baseLabel: TextView
    private lateinit var baseEdit: EditText
    private lateinit var enableSwitch: Switch
    private lateinit var current: Provider
    private val io = Executors.newSingleThreadExecutor()
    private val purple = 0xFF7C3AED.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        current = AiPrefs.provider(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.fitsSystemWindows = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), dp(40))
        scroll.addView(col)

        col.addView(title("Gizli Panel"))

        col.addView(label("Yapay zeka sağlayıcısı"))
        spinner = Spinner(this)
        val providers = Provider.values()
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, providers.map { it.label }
        )
        col.addView(spinner)

        col.addView(label("API Key (bu sağlayıcı için)"))
        keyEdit = edit("API key yapıştır")
        col.addView(keyEdit)

        col.addView(label("Model"))
        modelEdit = edit("model adı")
        col.addView(modelEdit)

        baseLabel = label("Base URL (örn. https://api.xxx.com/v1)")
        baseEdit = edit("https://.../v1")
        col.addView(baseLabel)
        col.addView(baseEdit)

        loadFields()
        updateBaseVisibility()
        spinner.setSelection(providers.indexOf(current))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val np = providers[pos]
                if (np != current) {
                    persist()          // eski sağlayıcının alanlarını kaydet
                    current = np
                    AiPrefs.setProvider(this@SecretActivity, np)
                    loadFields()
                }
                updateBaseVisibility()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        col.addView(button("Kaydet") {
            save()
            status.text = "Kaydedildi ✓"
        })

        col.addView(button("API'yi test et") {
            save()
            val cfg = AiPrefs.load(this)
            if (cfg.apiKey.isEmpty()) {
                status.text = "Önce API key gir"
            } else {
                status.text = "Test ediliyor…"
                io.execute {
                    val r = AiClient.ask(cfg, "Sadece rakamla cevap ver: 2+2 kaç?", null)
                    runOnUiThread { status.text = "Test sonucu: $r" }
                }
            }
        })

        enableSwitch = Switch(this)
        enableSwitch.text = "Ses kısma (V) tuşuyla çalıştır"
        enableSwitch.setTextColor(Color.WHITE)
        enableSwitch.textSize = 16f
        enableSwitch.isChecked = AiPrefs.enabled(this)
        enableSwitch.setOnCheckedChangeListener { _, checked -> AiPrefs.setEnabled(this, checked) }
        val swLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        swLp.topMargin = dp(20)
        col.addView(enableSwitch, swLp)

        col.addView(button("Erişilebilirlik ayarlarını aç") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        if (Build.VERSION.SDK_INT < 30) {
            col.addView(button("Ekran kaydı izni ver (Android 10)") {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
            })
        }

        status = TextView(this)
        status.setTextColor(0xFFD8B4FE.toInt())
        status.textSize = 15f
        val stLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        stLp.topMargin = dp(20)
        col.addView(status, stLp)

        setContentView(scroll)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenCaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                status.text = "Ekran kaydı izni verildi ✓"
            } else {
                status.text = "Ekran kaydı izni verilmedi"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        var s = "Servis: " + if (isServiceEnabled()) "AÇIK ✓" else
            "KAPALI ✗ — 'Erişilebilirlik ayarlarını aç' → Hesap Makinesi → Aç"
        if (Build.VERSION.SDK_INT < 30) {
            s += "\nEkran kaydı: " + if (ScreenCaptureService.ready) "HAZIR ✓" else "İZİN YOK ✗"
        }
        status.text = s
    }

    private fun isServiceEnabled(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return s.contains("$packageName/")
    }

    private fun loadFields() {
        keyEdit.setText(AiPrefs.key(this, current))
        modelEdit.setText(AiPrefs.model(this, current))
        modelEdit.hint = current.defaultModel
        baseEdit.setText(AiPrefs.baseUrl(this, Provider.CUSTOM))
    }

    private fun updateBaseVisibility() {
        val v = if (current == Provider.CUSTOM) View.VISIBLE else View.GONE
        baseLabel.visibility = v
        baseEdit.visibility = v
    }

    private fun persist() {
        AiPrefs.save(
            this, current,
            keyEdit.text.toString(), modelEdit.text.toString(), baseEdit.text.toString()
        )
    }

    private fun save() {
        persist()
        AiPrefs.setProvider(this, current)
    }

    private fun title(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 28f
        tv.setPadding(0, 0, 0, dp(16))
        return tv
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(0xFFA855F7.toInt())
        tv.textSize = 14f
        tv.setPadding(0, dp(14), 0, 0)
        return tv
    }

    private fun edit(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(0xFF6B6B80.toInt())
        e.inputType = InputType.TYPE_CLASS_TEXT
        e.isSingleLine = true
        e.backgroundTintList = ColorStateList.valueOf(purple)
        return e
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.stateListAnimator = null
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(purple)
        b.background = bg
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.topMargin = dp(14)
        b.layoutParams = lp
        return b
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQ_CAPTURE = 100
    }
}
