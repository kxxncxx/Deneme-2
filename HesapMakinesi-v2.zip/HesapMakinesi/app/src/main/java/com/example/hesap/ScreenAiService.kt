package com.example.hesap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.annotation.TargetApi
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Ses kısma tuşuna BASILI TUTUNCA: ekran görüntüsü alır, yapay zekaya sorar, cevabı gösterir.
 * Parmak çekilince cevap kaybolur. Her yeni basışta yeni cevap alınır.
 */
class ScreenAiService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private var overlay: TextView? = null

    // Her bas/çek olayında artar. Eski isteklerin cevabı, parmak çekildiyse veya yeni basış olduysa atılır.
    @Volatile
    private var gen = 0

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!AiPrefs.enabled(this)) return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) onPress()
            KeyEvent.ACTION_UP -> onRelease()
        }
        return true // ses seviyesi değişmesin
    }

    private fun onPress() {
        val myGen = ++gen
        removeOverlay() // kutu ekran görüntüsüne girmesin
        val cfg = AiPrefs.load(this)
        if (cfg.apiKey.isEmpty()) {
            show("API key girilmemiş")
            return
        }
        main.postDelayed({ if (myGen == gen) capture(cfg, myGen) }, 120)
    }

    private fun onRelease() {
        gen++
        removeOverlay()
    }

    private fun capture(cfg: AiConfig, myGen: Int) {
        if (Build.VERSION.SDK_INT >= 30) {
            captureApi30(cfg, myGen)
        } else {
            // Android 10: MediaProjection
            if (!ScreenCaptureService.ready) {
                show("Ekran kaydı izni yok. Gizli panelden izin ver.")
                return
            }
            ScreenCaptureService.capture { bmp ->
                io.execute { process(bmp, cfg, myGen) }
            }
        }
    }

    @TargetApi(30)
    private fun captureApi30(cfg: AiConfig, myGen: Int) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, io, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val bmp = try {
                        val hb = result.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        val copy = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        hw?.recycle()
                        copy
                    } catch (e: Exception) {
                        null
                    }
                    process(bmp, cfg, myGen)
                }

                override fun onFailure(errorCode: Int) {
                    main.post { if (myGen == gen) show("Ekran alınamadı ($errorCode)") }
                }
            })
        } catch (e: Exception) {
            show("Hata: ${e.message}")
        }
    }

    /** io thread'inde çalışır */
    private fun process(bmp: Bitmap?, cfg: AiConfig, myGen: Int) {
        if (myGen != gen) return
        if (bmp == null) {
            main.post { if (myGen == gen) show("Ekran görüntüsü alınamadı") }
            return
        }
        val answer = try {
            val maxSide = 1280f
            val scale = minOf(1f, maxSide / maxOf(bmp.width, bmp.height).toFloat())
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true
                )
            } else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

            main.post { if (myGen == gen) show("…") }
            AiClient.ask(cfg, PROMPT, b64)
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
        main.post { if (myGen == gen) show(answer) }
    }

    private fun show(message: String) {
        try {
            val existing = overlay
            if (existing != null) {
                existing.text = message
                return
            }
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val tv = TextView(this)
            tv.text = message
            tv.setTextColor(Color.WHITE)
            tv.textSize = 16f
            tv.maxWidth = (resources.displayMetrics.widthPixels * 0.8f).toInt()
            tv.setPadding(dp(12), dp(8), dp(12), dp(8))
            val bg = GradientDrawable()
            bg.setColor(0xE6120A24.toInt())
            bg.cornerRadius = dp(14).toFloat()
            bg.setStroke(dp(1), 0xFF7C3AED.toInt())
            tv.background = bg

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.BOTTOM or Gravity.START
            params.x = dp(8)
            params.y = dp(8)
            wm.addView(tv, params)
            overlay = tv
        } catch (e: Exception) {
            // overlay eklenemezse sessizce geç
        }
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
        overlay = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        gen++
        removeOverlay()
        io.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val PROMPT =
            "Bu ekran görüntüsündeki soruyu çöz. SADECE cevabı yaz. " +
                "Çoktan seçmeliyse doğru şıkkı kısaca yaz (örn. 'B) 12'). " +
                "Değilse tek satırlık çok kısa cevap ver. " +
                "Açıklama, giriş veya yorum yazma. Soru Türkçe değilse soru dilinde cevapla."
    }
}
