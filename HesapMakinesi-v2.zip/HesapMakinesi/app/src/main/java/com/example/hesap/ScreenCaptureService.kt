package com.example.hesap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Sadece Android 10 (API 29) için: AccessibilityService.takeScreenshot() API 30+ olduğundan
 * Android 10'da ekran görüntüsü MediaProjection ile alınır.
 */
class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private val thread = HandlerThread("cap").apply { start() }
    private val handler = Handler(thread.looper)

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("cap", "Ekran okuma", NotificationManager.IMPORTANCE_MIN)
        )
        val notif = Notification.Builder(this, "cap")
            .setContentTitle("Hesap Makinesi")
            .setContentText("Çalışıyor")
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection?.stop()
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                projection = null
                instance = null
                stopSelf()
            }
        }, handler)
        projection = p
        instance = this
        return START_NOT_STICKY
    }

    private fun doCapture(cb: (Bitmap?) -> Unit) {
        val proj = projection
        if (proj == null) {
            cb(null)
            return
        }
        handler.post {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            val w = dm.widthPixels
            val h = dm.heightPixels
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            var vd: VirtualDisplay? = null
            var done = false

            fun finish(b: Bitmap?) {
                if (done) return
                done = true
                try { vd?.release() } catch (e: Exception) {}
                try { reader.close() } catch (e: Exception) {}
                cb(b)
            }

            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    val bmp = try { toBitmap(img, w, h) } catch (e: Exception) { null }
                    img.close()
                    finish(bmp)
                }
            }, handler)

            try {
                vd = proj.createVirtualDisplay(
                    "cap", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.surface, null, handler
                )
                handler.postDelayed({ finish(null) }, 2500)
            } catch (e: Exception) {
                finish(null)
            }
        }
    }

    private fun toBitmap(img: Image, w: Int, h: Int): Bitmap {
        val plane = img.planes[0]
        val rowPixels = plane.rowStride / plane.pixelStride
        val full = Bitmap.createBitmap(rowPixels, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        return if (rowPixels != w) Bitmap.createBitmap(full, 0, 0, w, h) else full
    }

    override fun onDestroy() {
        instance = null
        projection?.stop()
        projection = null
        thread.quitSafely()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: ScreenCaptureService? = null

        val ready: Boolean get() = instance?.projection != null

        fun capture(cb: (Bitmap?) -> Unit) {
            val s = instance
            if (s == null) cb(null) else s.doCapture(cb)
        }
    }
}
