package com.example.hesap

import android.content.Context

enum class Provider(
    val id: String,
    val label: String,
    val defaultModel: String,
    val baseUrl: String
) {
    GEMINI("gemini", "Google Gemini", "gemini-2.5-flash", ""),
    OPENAI("openai", "OpenAI (ChatGPT)", "gpt-4o", "https://api.openai.com/v1"),
    CLAUDE("claude", "Anthropic Claude", "claude-sonnet-5-5", "https://api.anthropic.com/v1"),
    GROQ("groq", "Groq", "meta-llama/llama-4-scout-17b-16e-instruct", "https://api.groq.com/openai/v1"),
    OPENROUTER("openrouter", "OpenRouter (hepsi tek key)", "google/gemini-2.5-flash", "https://openrouter.ai/api/v1"),
    CUSTOM("custom", "Özel (OpenAI uyumlu)", "", "");

    companion object {
        fun fromId(id: String?): Provider = values().firstOrNull { it.id == id } ?: GEMINI
    }
}

data class AiConfig(
    val provider: Provider,
    val apiKey: String,
    val model: String,
    val baseUrl: String
)

object AiPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun provider(c: Context): Provider = Provider.fromId(prefs(c).getString("provider", "gemini"))

    fun setProvider(c: Context, p: Provider) {
        prefs(c).edit().putString("provider", p.id).apply()
    }

    fun key(c: Context, p: Provider): String {
        val v = prefs(c).getString("key_${p.id}", null)
        if (v == null && p == Provider.GEMINI) {
            // eski sürümden kalan key
            return prefs(c).getString("api_key", "").orEmpty()
        }
        return v.orEmpty()
    }

    fun model(c: Context, p: Provider): String {
        val v = prefs(c).getString("model_${p.id}", null)
        if (v == null && p == Provider.GEMINI) {
            val old = prefs(c).getString("model", "").orEmpty()
            if (old.isNotBlank()) return old
        }
        return v?.takeIf { it.isNotBlank() } ?: p.defaultModel
    }

    fun baseUrl(c: Context, p: Provider): String =
        if (p == Provider.CUSTOM) prefs(c).getString("base_custom", "").orEmpty() else p.baseUrl

    fun save(c: Context, p: Provider, key: String, model: String, base: String) {
        val e = prefs(c).edit()
            .putString("key_${p.id}", key.trim())
            .putString("model_${p.id}", model.trim())
        if (p == Provider.CUSTOM) e.putString("base_custom", base.trim())
        e.apply()
    }

    fun load(c: Context): AiConfig {
        val p = provider(c)
        return AiConfig(p, key(c, p).trim(), model(c, p).trim(), baseUrl(c, p).trim())
    }

    fun enabled(c: Context): Boolean = prefs(c).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("enabled", v).apply()
    }
}
