package com.example.hesap

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {

    /** Arka plan thread'inde çağır. jpegBase64 null ise sadece metin gönderir. */
    fun ask(cfg: AiConfig, prompt: String, jpegBase64: String?): String {
        if (cfg.apiKey.isEmpty()) return "API key girilmemiş"
        val model = cfg.model.ifEmpty { cfg.provider.defaultModel }
        if (model.isEmpty()) return "Model adı girilmemiş"
        return try {
            when (cfg.provider) {
                Provider.GEMINI -> gemini(cfg.apiKey, model, prompt, jpegBase64)
                Provider.CLAUDE -> claude(cfg, model, prompt, jpegBase64)
                else -> openAiStyle(cfg, model, prompt, jpegBase64)
            }
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
    }

    // ---------- Gemini ----------
    private fun gemini(key: String, model: String, prompt: String, img: String?): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (img != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", img)
                )
            )
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        val (code, text) = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to key),
            body
        )
        if (code !in 200..299) return errorMsg(code, text)
        val cands = JSONObject(text).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) return "Cevap alınamadı"
        val outParts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: return "Cevap alınamadı"
        val sb = StringBuilder()
        for (i in 0 until outParts.length()) sb.append(outParts.getJSONObject(i).optString("text", ""))
        return sb.toString().trim().ifEmpty { "Cevap alınamadı" }
    }

    // ---------- Anthropic Claude ----------
    private fun claude(cfg: AiConfig, model: String, prompt: String, img: String?): String {
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)
                )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", prompt))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val (code, text) = post(
            cfg.baseUrl.trimEnd('/') + "/messages",
            mapOf("x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01"),
            body
        )
        if (code !in 200..299) return errorMsg(code, text)
        val arr = JSONObject(text).optJSONArray("content") ?: return "Cevap alınamadı"
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text", ""))
        }
        return sb.toString().trim().ifEmpty { "Cevap alınamadı" }
    }

    // ---------- OpenAI, Groq, OpenRouter, özel (OpenAI uyumlu) ----------
    private fun openAiStyle(cfg: AiConfig, model: String, prompt: String, img: String?): String {
        if (cfg.baseUrl.isEmpty()) return "Base URL girilmemiş"
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", prompt))
        if (img != null) {
            content.put(
                JSONObject().put("type", "image_url").put(
                    "image_url",
                    JSONObject().put("url", "data:image/jpeg;base64,$img")
                )
            )
        }
        val body = JSONObject()
            .put("model", model)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val (code, text) = post(
            cfg.baseUrl.trimEnd('/') + "/chat/completions",
            mapOf("Authorization" to "Bearer ${cfg.apiKey}"),
            body
        )
        if (code !in 200..299) return errorMsg(code, text)
        val choices = JSONObject(text).optJSONArray("choices")
        if (choices == null || choices.length() == 0) return "Cevap alınamadı"
        val answer = choices.getJSONObject(0).optJSONObject("message")?.optString("content", "").orEmpty()
        return answer.trim().ifEmpty { "Cevap alınamadı" }
    }

    // ---------- ortak ----------
    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            return Pair(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMsg(code: Int, text: String): String {
        val msg = try {
            val err = JSONObject(text).opt("error")
            when (err) {
                is JSONObject -> err.optString("message", text.take(150))
                is String -> err
                else -> text.take(150)
            }
        } catch (e: Exception) {
            text.take(150)
        }
        return "Hata $code: $msg"
    }
}
