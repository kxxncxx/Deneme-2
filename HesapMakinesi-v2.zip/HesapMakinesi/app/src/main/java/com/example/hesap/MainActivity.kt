package com.example.hesap

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : Activity() {

    private lateinit var screenText: TextView
    private var expr = ""
    private var justEvaluated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(10), dp(10), dp(10), dp(10))
        root.fitsSystemWindows = true

        screenText = TextView(this)
        screenText.text = "0"
        screenText.setTextColor(Color.WHITE)
        screenText.gravity = Gravity.BOTTOM or Gravity.END
        screenText.maxLines = 2
        screenText.setPadding(dp(8), 0, dp(8), dp(16))
        screenText.setAutoSizeTextTypeUniformWithConfiguration(
            24, 64, 2, TypedValue.COMPLEX_UNIT_SP
        )
        root.addView(
            screenText,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f)
        )

        val rows = listOf(
            listOf("C", "⌫", "÷", "×"),
            listOf("7", "8", "9", "−"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", "="),
            listOf("0", ".")
        )
        for (row in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (label in row) {
                val weight = if (label == "0") 3f else 1f
                val b = Button(this)
                b.text = label
                b.setTextColor(Color.WHITE)
                b.textSize = 26f
                b.isAllCaps = false
                b.stateListAnimator = null
                val bg = GradientDrawable()
                bg.cornerRadius = dp(22).toFloat()
                bg.setColor(colorFor(label))
                b.background = bg
                b.setOnClickListener { onKey(label) }
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                line.addView(b, lp)
            }
            root.addView(
                line,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(root)
    }

    private fun colorFor(label: String): Int = when (label) {
        "=" -> 0xFFA855F7.toInt()
        "+", "−", "×", "÷" -> 0xFF7C3AED.toInt()
        "C", "⌫" -> 0xFF3B2A63.toInt()
        else -> 0xFF1C1530.toInt()
    }

    private fun onKey(label: String) {
        when (label) {
            "C" -> {
                expr = ""
                justEvaluated = false
            }
            "⌫" -> {
                if (justEvaluated) {
                    expr = ""
                    justEvaluated = false
                } else {
                    expr = expr.dropLast(1)
                }
            }
            "=" -> {
                equalsPressed()
                return
            }
            "+", "−", "×", "÷" -> operatorPressed(label)
            else -> digitPressed(label)
        }
        render()
    }

    private fun digitPressed(d: String) {
        if (justEvaluated) {
            expr = ""
            justEvaluated = false
        }
        if (expr.length >= 30) return
        val segment = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (d == ".") {
            if (segment.contains('.')) return
            if (segment.isEmpty()) expr += "0"
            expr += d
        } else {
            if (segment == "0") {
                expr = expr.dropLast(1) + d
            } else {
                expr += d
            }
        }
    }

    private fun operatorPressed(o: String) {
        justEvaluated = false
        if (expr.isEmpty()) {
            if (o == "−") expr = "−"
            return
        }
        if (expr == "−") return
        val last = expr.last()
        expr = if (last == '+' || last == '−' || last == '×' || last == '÷' || last == '.') {
            expr.dropLast(1) + o
        } else {
            expr + o
        }
    }

    private fun equalsPressed() {
        if (expr.isEmpty()) return
        var e = expr
        while (e.isNotEmpty() && e.last() in "+−×÷.") e = e.dropLast(1)
        if (e.isEmpty()) return

        val secret = (e == "31×31")
        try {
            val v = Parser(e.replace('×', '*').replace('÷', '/').replace('−', '-')).parse()
            expr = format(v)
            justEvaluated = true
            render()
        } catch (ex: Exception) {
            expr = ""
            justEvaluated = false
            screenText.text = "Hata"
            return
        }
        if (secret) {
            startActivity(Intent(this, SecretActivity::class.java))
        }
    }

    private fun render() {
        screenText.text = if (expr.isEmpty()) "0" else expr
    }

    private fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException()
        return BigDecimal(v).setScale(10, RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private class Parser(private val s: String) {
        private var p = 0

        fun parse(): Double {
            val v = expression()
            if (p < s.length) throw IllegalArgumentException()
            return v
        }

        private fun expression(): Double {
            var v = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) {
                val op = s[p++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) {
                val op = s[p++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            if (p < s.length && s[p] == '-') {
                p++
                return -factor()
            }
            val start = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (start == p) throw IllegalArgumentException()
            return s.substring(start, p).toDouble()
        }
    }
}
